%% Recreation of polygon unit from professor
clear all; close all; clc;

%% Material properties: Aluminum 2024 for bars, Steel cables
E_bars = 73*10^9; % Pascals
E_strings = 200*10^6; % Pa
A_bars = pi*(0.05)^2; % m^2, 5cm bars
A_strings = pi*(0.005)^2; % 1cm cables

%% Unit Geometry
p = 6; % polygon side number
% polygon parameters
R = 1; 
r = sqrt(3)*R/2; % inradius of a hexagon
h = 1;
h_ratio = 0.4;
r_ratio = 0.4;

%% Generate nodes and connectivity for unit
N_unit = generate_N(p,R,h,r_ratio,h_ratio);
n_N = length(N_unit(1,:)); % number of nodes
unit_height = h*(2-h_ratio);
% Bar connectivity index
C_b_in = bar_connectivity(p);
C_b_unit = tenseg_ind2C(C_b_in,N_unit);

% String connectivity index
C_s_in = string_connectivity(p);
C_s_unit = tenseg_ind2C(C_s_in,N_unit);

C_unit = [C_b_unit;C_s_unit];

%% Creating a base of repeated units
qx = 2; qy = 2; % create a grid of units

[N,C_b,C_s] = hex_array(N_unit,C_b_unit,C_s_unit,qy,R);
[N,C_b,C_s] = hex_xarray(N,C_b,C_s,qx,R);
[N,C_b,C_s] = tenseg_delete_dup(N,C_b,C_s); % delete repeated nodes and fix connectivity
tenseg_plot(N,C_b,C_s);

%% Finding pinned and free nodes: pinned nodes on ground
index_pinned = find((N(3,:) - 0.1) < 0);
C=[C_b;C_s]; % combined connectivity matrix
[n_elem, n_nodes] = size(C); % number of elements and number of nodes
[Ia,Ib,a,b] = tenseg_boundary(index_pinned,index_pinned,index_pinned,n_nodes);
%	Ia: transfer matrix of free coordinates
%	Ib: transfer matrix of pinned coordinates

%% Grouping top and bottom strings
string_grps = group_strings(N,C_s,h,h_ratio);
% plotting each string group in different colors
colors = [
    0.0000    0.4471    0.7412;   % Electric Blue
    0.8510    0.3255    0.0980;   % Vivid Orange
    0.9294    0.6941    0.1255;   % Strong Yellow
    0.4941    0.1843    0.5569;   % Saturated Purple
    0.0000    0.5020    0.0000;   % Deep Green
    0.8000    0.0000    0.0000;   % Crimson Red
];

% Plotting the groups on a single unit
string_grps_unit = group_strings(N_unit,C_s_unit,h,h_ratio);
fig = figure;

% tenseg_plot2(N,C_b,string_grps{1},fig,colors(1,:))
% plot only a unit
string_grps_unit = group_strings(N_unit,C_s_unit,h,h_ratio);
fig = figure;
lbl = ["Group 1", "Group 2", "Group 3", "Group 4", "Group 5", "Group 6"];
for i =1:6
    tenseg_plot2(N_unit,C_b_unit,string_grps_unit{i},fig,colors(i,:))

end
legend("", lbl(1), "", "", lbl(2),"", "", lbl(3),"", "", lbl(4),"", "", ...
    lbl(5),"", "", lbl(6),"")


%% Equilibrium analysis
% Weight of top structure
n_N = size(N,2); % update number of nodes without duplicates
weight_habitat = 10000; % 1 ton weight
g_moon = 1.62; % moon gravity
top_nodes = find(abs(N(3,:)-unit_height)<0.1); % top nodes are nodes within 0.1 of the unit-height
w_weight = weight_habitat/size(top_nodes,2); % force due to habitat on each top node

w_external = zeros(n_N,3); 
w_external(top_nodes,3) = -w_weight; % force at each top node in negative z-direction
w_external = reshape(w_external',n_N*3,1); % turn force matrix into vector
w_external = Ia'*w_external; % only free nodes

% Member forces/directions
B = N*C_b'; % bar matrix
S = N*C_s'; % string matrix

L_B = vecnorm(B,2,1); % lengths of bars
L_S = vecnorm(S,2,1); % lengths of strings

H_B = B./L_B; % unit vectors of directions of bars
H_S = S./L_S; % unit vectors of directions of strings

H = [H_B H_S]; % direction matrix of each member


% Stiffness
k_bars = E_bars * A_bars ./ L_B; % stiffness of bars (linear)
k_strings = E_strings * A_strings ./ L_S; % stiffness of strings (linear)
k = [k_bars k_strings];
C_index = C2C_i(C); % index notation [(start index) (end index)]
K = zeros(3*n_N); % Stiffness matrix in 3nx3n (3DOF per node, n nodes)

for i = 1:size(H,2)
    node1 = C_index(i,1); % starting node index
    node2 = C_index(i,2); % end node
    h_i = H(:,i); % direction of element i
    K_i = k(i)*(h_i*h_i'); % map axial stiffness to global x-y-z coordinates

    indx1 = (node1-1)*3 + (1:3); % index notation to degrees of freedom (3 per node, xyz)
    indx2 = (node2-1)*3 + (1:3);
    % assembling global stiffness K = [k_i -k_i;-k_i k_i]
    K(indx1,indx1) = K(indx1,indx1) + K_i;
    K(indx2,indx2) = K(indx2,indx2) + K_i;
    K(indx1,indx2) = K(indx1,indx2) - K_i;
    K(indx2,indx1) = K(indx2,indx1) - K_i;
end

K = Ia'*K*Ia; % remove fixed node DOF

% Solve statics problem: F = K*U
u_static = inv(K)*w_external; % displacement of nodes due to weight
u_static = Ia*u_static; % add back fixed nodes
u_static = reshape(u_static,3,n_N);
N_static = N+u_static;
tenseg_plot(N_static,C_b,C_s)


%% Prestressing strings

N_members = size(C_s,1); % total number of strings
N_groups = length(string_grps);
Gp = zeros(N_members, N_groups);
% Creating group matrix
for g = 1:N_groups
    % Convert group connectivity matrix to member indices
    member_indices = C2C_i(string_grps{g});  % gives indices of strings in this group
    Gp(member_indices, g) = 1;              % assign 1 in the corresponding column
end

% [A_1a,A_1ag,A_2a,A_2ag,l,l_gp] = tenseg_equilibrium_matrix1(N,C_s,Gp,Ia); % map member forces to nodal forces
% 
% [U1,U2,V1,V2,S1]=tenseg_svd(A_2ag); % V2 - prestress mode, member forces that result in equilbrium at nodes
% index_gp = [1];
% fd = 1000;
% [q_gp,t_gp,q,t]=tenseg_prestress_design(Gp,l,l_gp,A_2ag,V2,w_external,index_gp,fd);    %prestress design
% % t(t<0) = 0; % strings only in tension
% 
% F_strings = H_S.*t'; % forces along strings
% 
% F_prestress = zeros(3, n_N);
% C_s_index = C2C_i(C_s);
% 
% % applying forces in strings to nodes
% for i = 1:size(C_s_index,1)
%     nodes = C_s_index(i,:);
%     F_prestress(:,nodes(1)) = F_prestress(:,nodes(1)) + F_strings(:,i);
%     F_prestress(:,nodes(2)) = F_prestress(:,nodes(2)) - F_strings(:,i);
% end
% 
% F_prestress = reshape(F_prestress,3*n_N,1);
% F_prestress = Ia'*F_prestress; % Remove fixed nodes
% 
% u_prestress = K \ (F_prestress(:)+w_external);         % solve displacements
% u_prestress = Ia*u_prestress;
% u_prestress = reshape(u_prestress,3,n_N);
% N_prestress = N+u_prestress;
% 
% 
% tenseg_plot(N_prestress,C_b,C_s)
% tenseg_plot(N_static,C_b,C_s)
%% Dynamics

% node_mass = 5; % 5kg e.g.
% n_free = length(free_nodes);
% M = node_mass*eye(3*n_N);
% quake_data = readmatrix('waveform.csv');
% quake_data(:,2) = quake_data(:,2)*10^10;
% a_quake = [quake_data(:,2) quake_data(:,1)];
% v_quake = [cumtrapz(quake_data(:,1),quake_data(:,2)) quake_data(:,1)];
% d_quake = [cumtrapz(quake_data(:,1),v_quake(:,1)) quake_data(:,1)];
% 
% F_quake = zeros(3*n_N,size(a_quake,1));
% for i = 1:size(index_pinned,2)
%     F_quake(3*(index_pinned(i)-1)+1,:) = a_quake(:,1)';
% end
% F_quake = M*F_quake;
% 
% F_quake = Ia'*F_quake;
% 

