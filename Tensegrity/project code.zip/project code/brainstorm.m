%% Recreation of polygon unit from professor
clear all; close all; clc;

%% Material properties: Aluminum 2024 for bars, Steel cables
E_bars = 73*10^9; % Pascals
E_strings = 200*10^6; % Pa
A_bars = pi*(0.05)^2; % m^2, 5cm bars
A_strings = pi*(0.005)^2; % 1cm cables


%% Unit Geometry
p = 6; % polygon side number
% polygon parameters
R = 1; % 1 meter
r = sqrt(3)*R/2; % inradius of a hexagon
h = 1; % 1 meter
h_ratio = 0.4;
r_ratio = 0.4;

%% Generate nodes and connectivity for unit
N_unit = generate_N(p,R,h,r_ratio,h_ratio);
n_N = length(N_unit(1,:)); % number of nodes
unit_height = h*(2-h_ratio);
% Bar connectivity index
C_b_in = bar_connectivity(p);
C_b_unit = tenseg_ind2C(C_b_in,N_unit);

% String connectivity index
C_s_in = string_connectivity(p);
C_s_unit = tenseg_ind2C(C_s_in,N_unit);

C_unit = [C_b_unit;C_s_unit];
tenseg_plot(N_unit,C_b_unit,C_s_unit)
%% Creating a base of repeated units
qx = 2; qy = 2; % create a grid of units

[N,C_b,C_s] = hex_array(N_unit,C_b_unit,C_s_unit,qy,R);
[N,C_b,C_s] = hex_xarray(N,C_b,C_s,qx,R);
[N,C_b,C_s] = tenseg_delete_dup(N,C_b,C_s); % delete repeated nodes and fix connectivity
tenseg_plot(N,C_b,C_s);

%% Finding pinned and free nodes: pinned nodes on ground
index_pinned = find((N(3,:) - 0.1) < 0);
C=[C_b;C_s]; % combined connectivity matrix
[n_elem, n_nodes] =size(C); % number of elements and number of nodes
[Ia,Ib,a,b] = tenseg_boundary(index_pinned,index_pinned,index_pinned,n_nodes);

%% Grouping top and bottom strings
string_grps = group_strings(N,C_s,h,h_ratio);
% plotting each string group in different colors
colors = [
    0.0000    0.4471    0.7412;   % Electric Blue
    0.8510    0.3255    0.0980;   % Vivid Orange
    0.9294    0.6941    0.1255;   % Strong Yellow
    0.4941    0.1843    0.5569;   % Saturated Purple
    0.0000    0.5020    0.0000;   % Deep Green
    0.8000    0.0000    0.0000;   % Crimson Red
];
fig = figure;
for i =1:6
    tenseg_plot2(N,C_b,string_grps{i},fig,colors(i,:))
end
% G = tenseg_str_gp(string_grps,C);

%% Equilibrium analysis
n_N = size(N,2); % update number of nodes without duplicates
weight_habitat = 10000; % weight of top load
g_moon = 1.62; % moon gravity
top_nodes = find(abs(N(3,:)-unit_height)<0.1); % top nodes are nodes within
% 0.1 of the unit-height
w_weight = weight_habitat*g_moon/size(top_nodes,2); % force due to habitat 
% on each top node

w_external = zeros(n_N,3); 
w_external(top_nodes,3) = -w_weight; % force at each top node in negative
% z-direction
w_external = reshape(w_external',n_N*3,1); % turn force matrix into vector

%% Members
B = N*C_b';
L_B = vecnorm(B,2,1); % gets the relaxed length of each bar
H_B = B./L_B; % unit  direction of bars
S = N*C_s';
L_S = vecnorm(S,2,1); % gets the relaxed length of each string
H_S = S./L_S; % unit direction of strings

H = [H_B H_S];
% equilibrium matrix
% H(:,i) is the direction of member i
% bars
G = zeros(3*n_N,size(B,2)+size(S,2));
for i = 1:n_N
    G(3*i-2, :) = C(:,i).' .* H(1,:);   % x-component
    G(3*i-1, :) = C(:,i).' .* H(2,:);   % y-component
    G(3*i,   :) = C(:,i).' .* H(3,:);   % z-component
end

free_nodes = setdiff(1:n_N,index_pinned);
rows_free = reshape([3*free_nodes-2; 3*free_nodes-1; 3*free_nodes], 1, []);
% remove fixed nodes from G
G_free = G(rows_free, :); % only free nodes

w_free = w_external(rows_free);


m_b = size(C_b,1);
m_s = size(C_s,1);

Aeq = G;
beq = -w_free;
% Lower Constraints, bars have no compressive constraint, strings 
% must be in tension so must be zero if in compression
compression = [-inf(m_b,1);zeros(m_s,1)]; % bars are 1-m_b, strings are the rest
% Upper constraint, no constraints on string or bars in tension
tension = inf(m_b+m_s,1);

t_all = lsqlin(G_free,w_free,[],[],[],[],compression,tension); % forces in each member

% rows_fixed = reshape([3*index_pinned-2; 3*index_pinned-1; 3*index_pinned], 1, []);
% R_fixed = G(index_pinned,:) * t_all + w_external(index_pinned);
% Bar/string stiffness
k_bars = E_bars * A_bars ./ L_B;
k_strings = E_strings * A_strings ./ L_S;
K_members = diag([k_bars,k_strings]); % combine into structure stiffness


% Free nodes previously identified
delta_X_free = ((G_free * K_members * G_free')^-1)* w_free;

% Map back to nodes
N_new = N;
for i = 1:length(free_nodes)
    idx = free_nodes(i);
    N_new(:, idx) = N(:, idx) + delta_X_free(3*i-2:3*i);
end
tenseg_plot(N,C_b,C_s)
tenseg_plot(N_new,C_b,C_s)

%% quake response
% M*ddn + Kn + D*dn = F_ext
% M = mass matrix
% ddn - node acceleration (in vector form)
% dn = nodal velocity
% n = nodeal position
% K = Stiffness matrix
% D = damping 

node_mass = 5; % 5kg e.g.
n_free = length(free_nodes);
M = node_mass*eye(3*n_free);
D = zeros(3*n_free); % undamped response
K_nodes = G_free*K_members*G_free';
quake_data = readmatrix('waveform.csv');
quake_data(:,2) = quake_data(:,2)*10^10;

% X_0 = zeros(6*n_free,1);
% t_vec = 0:200;
% [t_out, N_out] = ode45(@(t,X) tenseg_dynamics(t,X,M,D,K_nodes,n_free,quake_data), t_vec, X_0);
% 
% 
% function dNdt = tenseg_dynamics(t,X,M,D,K,n_free,quake_data)
% position = X(1:3*n_free);
% velocity = X(3*n_free+1:end);
% 
% t_quake = quake_data(:,1);
% a_quake = [quake_data(:,2), zeros(size(quake_data(:,2))),zeros(size(quake_data(:,2)))];
% a_interp = interp1(t_quake,a_quake,t)';
% F = -M*repmat(a_interp,n_free,1); % forces on free nodes
% 
% accel = M\(F-D*velocity-K*position);
% dNdt = [velocity;accel];
% 
% end